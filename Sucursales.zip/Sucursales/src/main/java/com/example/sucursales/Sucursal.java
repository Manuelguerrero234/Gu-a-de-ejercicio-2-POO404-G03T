package com.example.sucursales;

import jakarta.persistence.*;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "sucursales")
public class Sucursal implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String calle;
    private String colonia;
    private String ciudad;
    private String departamento;
    private String telefono;

    @Column(name = "empleado_director")
    private String empleadoDirector;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmpleadoDirector() {
        return empleadoDirector;
    }

    public void setEmpleadoDirector(String empleadoDirector) {
        this.empleadoDirector = empleadoDirector;
    }
}