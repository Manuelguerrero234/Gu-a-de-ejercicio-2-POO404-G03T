package com.example.sucursales;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@ApplicationScoped
@Path("/sucursales")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SucursalResource {

    @Inject
        private EntityManager entityManager;

    @GET
    public List<Sucursal> getAllSucursales() {
        return entityManager.createQuery("SELECT s FROM Sucursal s", Sucursal.class).getResultList();
    }

    @GET
    @Path("/{id}")
    public Sucursal getSucursal(@PathParam("id") Long id) {
        return entityManager.find(Sucursal.class, id);
    }

    @POST
    @Transactional
    public Sucursal addSucursal(Sucursal sucursal) {
        entityManager.persist(sucursal);
        return sucursal;
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Sucursal updateSucursal(@PathParam("id") Long id, Sucursal sucursal) {
        Sucursal existingSucursal = entityManager.find(Sucursal.class, id);
        if (existingSucursal != null) {
            existingSucursal.setCalle(sucursal.getCalle());
            existingSucursal.setColonia(sucursal.getColonia());
            existingSucursal.setCiudad(sucursal.getCiudad());
            existingSucursal.setDepartamento(sucursal.getDepartamento());
            existingSucursal.setTelefono(sucursal.getTelefono());
            existingSucursal.setEncargado(sucursal.getEncargado());
            entityManager.merge(existingSucursal);
            return existingSucursal;
        }
        return null;
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public void deleteSucursal(@PathParam("id") Long id) {
        Sucursal sucursal = entityManager.find(Sucursal.class, id);
        if (sucursal != null) {
            entityManager.remove(sucursal);
        }
    }
}
